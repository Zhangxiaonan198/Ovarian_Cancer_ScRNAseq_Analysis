library(clusterProfiler)
library(org.Hs.eg.db)
library(DOSE)#可进行enrichDO等分析
library(dplyr) #进行数据转换
library(ggplot2)#绘图
library(enrichplot)#绘图
library(tidyverse)


# 读取xls结果文件
data<- read.delim(
  file = "C:/Users/eeeqi/Desktop/博士毕业论文存档/02原始数据/美吉SULT1C2-SKOV3敲减5V5/gene_counts.xls",
  header = TRUE,            # 第一行是列名
  sep = "\t",               # 制表符分隔
  row.names = 1,            # 首列是GO术语ID (自动设为行名)
  check.names = FALSE,      # 保留原始列名格式
  stringsAsFactors = FALSE
)

#DESeq2
#BiocManager::install("DESeq2")
library(DESeq2)
colnames(data)<-c("CONTROL1","CONTROL2","CONTROL3","CONTROL4","CONTROL5","TEST1","TEST2","TEST3","TEST4","TEST5")
colData<-data.frame(condition=c(rep("ctrl",5),rep("gbd",5)),row.names=colnames(data))
colData$condition <- factor(colData$condition, levels = c("ctrl","gbd"))
#colData$sex<-factor(c("male","male","male","female"),levels = c("male","female"))
cds<-DESeqDataSetFromMatrix(data,design=~condition,colData=colData)
#cds<-DESeqDataSetFromMatrix(data,design=~condition+sex,colData=colData)#加入协变量
keep <- rowSums(counts(cds) >= 1) >= 1#低表达基因过滤，保留至少1个样以上表达的基因，没有固定标准
#cds <- cds[keep, ] 
cds<-DESeq(cds)
res <- results(cds)#默认gbd/ctrl
#res1 <- results(cds, contrast = c("condition","ctrl","gbd"))#可设置谁和谁比gbd/ctrl
resOrdered <- res[order(res$padj),]
##counts(cds, normalized=TRUE)可用deseq2对表达量进行normalization，写进差异分析结果中
#保存全部结果
write.table(data.frame(resOrdered), file="C:/Users/eeeqi/Desktop/博士毕业论文存档/02原始数据/美吉SULT1C2-SKOV3敲减5V5/outputfile-DESeq2.txt",quote=F,sep="\t")

#提取上调差异基因并存结果
up_DEGs <- subset(res, pvalue < 0.05 & log2FoldChange > 1)#变化倍数可以调整
#write.table(up_DEGs, "C:/Users/eeeqi/Desktop/博士毕业论文存档/03分析结果/SULT1C2敲减转录组数据分析/美吉SULT1C2-SKOV3敲减5V5数据分析/up_DEGs_genes.xls", col.names = NA, quote=F, sep = "\t") 
write.table(up_DEGs,"C:/Users/eeeqi/Desktop/博士毕业论文存档/03分析结果/SULT1C2敲减转录组数据分析/美吉SULT1C2-SKOV3敲减5V5数据分析/up_DEGs_genes1.txt",sep="\t")
#提取下调差异基因并存结果
down_DEGs <- subset(res, pvalue < 0.05 & log2FoldChange < -0.5)#变化倍数可以调整
#write.table(down_DEGs, "C:/Users/eeeqi/Desktop/博士毕业论文存档/03分析结果/SULT1C2敲减转录组数据分析/美吉SULT1C2-SKOV3敲减5V5数据分析/down_DEGs_genes.xls", col.names = NA, quote=F, sep = "\t")
write.table(down_DEGs,file="C:/Users/eeeqi/Desktop/博士毕业论文存档/03分析结果/SULT1C2敲减转录组数据分析/美吉SULT1C2-SKOV3敲减5V5数据分析/down_DEGs_genes1.txt",sep="\t")

#保存上调差异基因列表，带基因名称
#导入数据
geneup<- read.table("C:/Users/eeeqi/Desktop/博士毕业论文存档/03分析结果/SULT1C2敲减转录组数据分析/美吉SULT1C2-SKOV3敲减5V5数据分析/up_DEGs_genes1.txt",header=T, sep="\t")
geneup1<- rownames(geneup)
geneup2<- bitr(geneup1, 
                 fromType = "ENSEMBL", 
                 toType = "SYMBOL", 
                 OrgDb = org.Hs.eg.db)
upgene <- geneup %>%
  rownames_to_column("ENSEMBL_VERSIONED") %>%
  mutate(ENSEMBL = sub("\\..*$", "", ENSEMBL_VERSIONED)) %>%
  left_join(geneup2, by = "ENSEMBL") %>%
  distinct(ENSEMBL_VERSIONED, .keep_all = TRUE)  # 确保唯一Ensembl ID
write.table(upgene, "C:/Users/eeeqi/Desktop/博士毕业论文存档/03分析结果/SULT1C2敲减转录组数据分析/美吉SULT1C2-SKOV3敲减5V5数据分析/upgenename.xls", col.names = NA, quote=F, sep = "\t") 
#保存下调差异基因列表，带基因名称
#导入数据
genedown<- read.table("C:/Users/eeeqi/Desktop/博士毕业论文存档/03分析结果/SULT1C2敲减转录组数据分析/美吉SULT1C2-SKOV3敲减5V5数据分析/down_DEGs_genes1.txt",header=T, sep="\t")
genedown1<- rownames(genedown)
genedown2<- bitr(genedown1, 
               fromType = "ENSEMBL", 
               toType = "SYMBOL", 
               OrgDb = org.Hs.eg.db)
downgene <- genedown %>%
  rownames_to_column("ENSEMBL_VERSIONED") %>%
  mutate(ENSEMBL = sub("\\..*$", "", ENSEMBL_VERSIONED)) %>%
  left_join(genedown2, by = "ENSEMBL") %>%
  distinct(ENSEMBL_VERSIONED, .keep_all = TRUE)  # 确保唯一Ensembl ID
write.table(downgene, "C:/Users/eeeqi/Desktop/博士毕业论文存档/03分析结果/SULT1C2敲减转录组数据分析/美吉SULT1C2-SKOV3敲减5V5数据分析/downgenename.xls", col.names = NA, quote=F, sep = "\t") 


#edgeR##也可以对基因按照表达样本数过滤
#library(edgeR)
#data<-data.frame(CONTROL[,2:3], kdMETTL3[,2:3],stringsAsFactors=F)
#rownames(data)<-CONTROL[,1]
#data<-as.matrix(data)
#g<-c("CONTROL","CONTROL","kdMETTL3","kdMETTL3")
#d<-DGEList(counts=data,group=g)
#d<-calcNormFactors(d)
#d<-estimateDisp(d)
#de.com<-exactTest(d)
#tTags<-topTags(de.com,n=Inf)
#write.table(tTags, file="D:/outputFile-edgeR.xls",sep="\t", quote=F, row.names=T)

#选择上调基因做go功能富集分析
gene1<- read.table("C:/Users/eeeqi/Desktop/博士毕业论文存档/03分析结果/SULT1C2敲减转录组数据分析/美吉SULT1C2-SKOV3敲减5V5数据分析/up_DEGs_genes1.txt",header=T, sep="\t")#导入数据
#allgene<- read.table(""C:/Users/eeeqi/Desktop/RDATA0113/outputfile-DESeq2.txt",header=T, sep="\t")

diff_gene <- rownames(gene1)
print(paste("共有", length(diff_gene), "个差异表达基因"))
# ========== 4. 基因ID转换（ENSEMBL → ENTREZ） ==========
# GO富集分析通常使用ENTREZ ID
id_conversion <- bitr(diff_gene, 
                      fromType = "ENSEMBL", 
                      toType = "ENTREZID", 
                      OrgDb = org.Hs.eg.db)

# 提取转换后的ENTREZ ID
diff_gene_entrez <- id_conversion$ENTREZID
print(paste("成功转换", length(diff_gene_entrez), "个基因"))
ego_bp <- enrichGO(gene          = diff_gene_entrez,
                   OrgDb         = org.Hs.eg.db,
                   keyType       = "ENTREZID",
                   ont           = "BP",   # 生物过程
                   pAdjustMethod = "BH",   # Benjamini-Hochberg校正
                   pvalueCutoff  = 0.05,   # p值阈值
                   qvalueCutoff  = 0.2,
                   readable      = TRUE)   # 输出可读的基因名
ego_mf <- enrichGO(gene          = diff_gene_entrez,
                   OrgDb         = org.Hs.eg.db,
                   keyType       = "ENTREZID",
                   ont           = "MF",   # 分子功能
                   pAdjustMethod = "BH",
                   pvalueCutoff  = 0.05,
                   qvalueCutoff  = 0.2,
                   readable      = TRUE)
ego_all <- enrichGO(gene          = diff_gene_entrez,
                   OrgDb         = org.Hs.eg.db,
                   keyType       = "ENTREZID",
                   ont           = "ALL",   # 全部
                   pAdjustMethod = "BH",
                   pvalueCutoff  = 0.05,
                   qvalueCutoff  = 0.2,
                   readable      = TRUE)
cat("\n===== 生物过程(BP)富集结果 =====\n")
head(ego_bp)
cat("\n===== 分子功能(MF)富集结果 =====\n")
head(ego_mf)

#存储结果
write.table(ego_bp@result, "C:/Users/eeeqi/Desktop/博士毕业论文存档/03分析结果/SULT1C2敲减转录组数据分析/美吉SULT1C2-SKOV3敲减5V5数据分析/GO_BPup_enrichment_results.xls", col.names = NA, quote=F, sep = "\t") 
write.table(ego_mf@result, "C:/Users/eeeqi/Desktop/博士毕业论文存档/03分析结果/SULT1C2敲减转录组数据分析/美吉SULT1C2-SKOV3敲减5V5数据分析/GO_MFup_enrichment_results.xls", col.names = NA, quote=F, sep = "\t") 
write.table(ego_all@result, "C:/Users/eeeqi/Desktop/博士毕业论文存档/03分析结果/SULT1C2敲减转录组数据分析/美吉SULT1C2-SKOV3敲减5V5数据分析/GO_ALLup_enrichment_results.xls", col.names = NA, quote=F, sep = "\t") 
write.csv(ego_bp@result, "C:/Users/eeeqi/Desktop/博士毕业论文存档/03分析结果/SULT1C2敲减转录组数据分析/美吉SULT1C2-SKOV3敲减5V5数据分析/GO_BPup_enrichment_results.csv", row.names = FALSE)
write.csv(ego_mf@result, "C:/Users/eeeqi/Desktop/博士毕业论文存档/03分析结果/SULT1C2敲减转录组数据分析/美吉SULT1C2-SKOV3敲减5V5数据分析/GO_MFup_enrichment_results.csv", row.names = FALSE)

#可视化
#气泡图
p1 <- dotplot(ego_bp, showCategory = 10) + 
  ggtitle("GO Biological Process") +
  theme(plot.title = element_text(hjust = 0.5))
p2 <- dotplot(ego_mf, showCategory = 10) + 
  ggtitle("GO Molecular Function") +
  theme(plot.title = element_text(hjust = 0.5))
print(p1)
print(p2)
#另一种画气泡图的方法
#dotplot(ego_bp,showCategory=10)#气泡图
#dotplot(ego_bp,showCategory=10)+ggtitle("dotplot for GO")#气泡图


#柱状图
barplot(ego_bp,showCategory=10)
ctgy <- c("regulation of viral process","viral genome replication")##设定特定通路
barplot(ego_bp,showCategory=ctgy)#柱状图
##其它可视化的图，cnetplot, heatplot, emapplot, goplot等，参考https://blog.csdn.net/weixin_43358851/article/details/83378100
cnetplot(ego_bp,showCategory = 2)
##自定义要展示的标签
cnetplot(ego_bp, node_label="category",cex_label_category = 1.2)
cnetplot(ego_bp, node_label="gene", cex_label_gene = 0.8)
cnetplot(ego_bp, node_label="all")
cnetplot(ego_bp, node_label="none",color_category='firebrick',color_item ='steelblue')
cnetplot(ego_bp, node_label="all",cex_label_category = 1.2)

heatplot(ego_bp, showCategory = 8, #显示前8
         symbol = "rect", # 图形，可选"dot"
         pvalue = NULL,
         label_format = 30)

heatplot(ego_bp, showCategory = 8, #显示前8
         symbol = "dot", #改为dot
         pvalue = NULL,
         label_format = 30)

##画通路网络图
go1<- pairwise_termsim(ego_bp)
dim(go1@result)
emapplot(go1)
upsetplot(go1)

#将BP、MF、CC途径的富集结果挑选前5条绘制在一张图上
dotplot(ego_all, split="ONTOLOGY",showCategory=5)+ facet_grid(ONTOLOGY~.,scale="free")
barplot(ego_all, split="ONTOLOGY",showCategory=5)+ facet_grid(ONTOLOGY~.,scale="free")
#将ont=ALL，换成CC、BP、MF分别进行富集
goCC <- enrichGO(diff_gene_entrez,OrgDb = org.Hs.eg.db, ont='CC',pAdjustMethod = 'BH',pvalueCutoff = 0.05, qvalueCutoff = 0.2,keyType = 'ENTREZID')
goBP <- enrichGO(diff_gene_entrez,OrgDb = org.Hs.eg.db, ont='BP',pAdjustMethod = 'BH',pvalueCutoff = 0.05, qvalueCutoff = 0.2,keyType = 'ENTREZID')
goplot(goBP, showCategory = 5)#注意需要在单个CC、BP、MF结果中绘图
goMF <- enrichGO(diff_gene_entrez,OrgDb = org.Hs.eg.db, ont='MF',pAdjustMethod = 'BH',pvalueCutoff = 0.05, qvalueCutoff = 0.2,keyType = 'ENTREZID')
goplot(goMF, showCategory = 5)



# 1. KEGG富集 ID转换
id_conversion <- bitr(diff_gene, 
                      fromType = "ENSEMBL", 
                      toType = c("ENTREZID", "SYMBOL"),
                      OrgDb = org.Hs.eg.db)

# 2. 提取唯一ENTREZID
diff_gene_entrez <- unique(na.omit(id_conversion$ENTREZID))

# 3. KEGG富集
kegg <- enrichKEGG(gene = diff_gene_entrez,
                   organism = 'hsa',
                   keyType = 'kegg',
                   pvalueCutoff = 0.05,
                   pAdjustMethod = 'BH',
                   minGSSize = 3,
                   maxGSSize = 500,
                   qvalueCutoff = 0.2,
                   use_internal_data = FALSE)

# =========================================================================
# 【关键步骤】把 geneID 转换成 基因名（SYMBOL）
# =========================================================================
kegg_df <- setReadable(kegg, OrgDb = org.Hs.eg.db, keyType = "ENTREZID")

# 4. 导出带基因名的结果表格（geneID列直接是基因名）
write.csv(kegg_df, file = "C:/Users/eeeqi/Desktop/博士毕业论文存档/03分析结果/SULT1C2敲减转录组数据分析/美吉SULT1C2-SKOV3敲减5V5数据分析/keggup_with_gene_names.csv", row.names = F)

# 5. 查看（现在已经显示基因名）
head(kegg_df$geneID)

# 6. 画图（自动显示基因名）
dotplot(kegg_df, showCategory = 10, title = "KEGG Enrichment (Down-regulated genes)")
barplot(kegg_df, showCategory = 10, title = "KEGG Barplot")



##其它富集方法
ENid<-unique(id_conversion$ENTREZID)
DO <- enrichDO(gene          = ENid,
               ont           = "HDO",
               pvalueCutoff  = 0.05,
               pAdjustMethod = "BH",
               universe      = names(ENid),
               minGSSize     = 5,
               maxGSSize     = 500,
               qvalueCutoff  = 0.05,
               readable      = FALSE)
#使用 enrichDO进行 DO(疾病本体论)富集
ncg <- enrichNCG(ENid)#使用enrichNCG 进行癌基因网络富集
dgn<-enrichDGN(ENid)#使用 enrichDGN 进行疾病基因网络富集
write.csv(DO,file = "C:/Users/eeeqi/Desktop/博士毕业论文存档/03分析结果/SULT1C2敲减转录组数据分析/美吉SULT1C2-SKOV3敲减5V5数据分析/do.csv")
write.table(DO, "C:/Users/eeeqi/Desktop/博士毕业论文存档/03分析结果/SULT1C2敲减转录组数据分析/美吉SULT1C2-SKOV3敲减5V5数据分析/do.xls", col.names = NA, quote=F, sep = "\t")
write.csv(ncg,file = "C:/Users/eeeqi/Desktop/博士毕业论文存档/03分析结果/SULT1C2敲减转录组数据分析/美吉SULT1C2-SKOV3敲减5V5数据分析/ncg.csv")
write.table(ncg, "C:/Users/eeeqi/Desktop/博士毕业论文存档/03分析结果/SULT1C2敲减转录组数据分析/美吉SULT1C2-SKOV3敲减5V5数据分析/ncg.xls", col.names = NA, quote=F, sep = "\t")
write.csv(dgn,file = "C:/Users/eeeqi/Desktop/博士毕业论文存档/03分析结果/SULT1C2敲减转录组数据分析/美吉SULT1C2-SKOV3敲减5V5数据分析/dgn.csv")
write.table(dgn, "C:/Users/eeeqi/Desktop/博士毕业论文存档/03分析结果/SULT1C2敲减转录组数据分析/美吉SULT1C2-SKOV3敲减5V5数据分析/dgn.xls", col.names = NA, quote=F, sep = "\t")
dim(ncg@result)
#可视化，同上
dotplot(dgn, showCategory=10) #气泡图
dotplot(ncg, showCategory=10) #气泡图
barplot(dgn,showCategory=10,drop=T) #柱状图
dotplot(DO, showCategory=10) #气泡图


#可视化
#气泡图
p1 <- dotplot(ego_bp, showCategory = 10) + 
  ggtitle("GO Biological Process") +
  theme(plot.title = element_text(hjust = 0.5))
p2 <- dotplot(ego_mf, showCategory = 10) + 
  ggtitle("GO Molecular Function") +
  theme(plot.title = element_text(hjust = 0.5))
print(p1)
print(p2)
#另一种画气泡图的方法
#dotplot(ego_bp,showCategory=10)#气泡图
#dotplot(ego_bp,showCategory=10)+ggtitle("dotplot for GO")#气泡图


#柱状图
barplot(ego_bp,showCategory=10)
ctgy <- c("regulation of viral process","viral genome replication")##设定特定通路
barplot(ego_bp,showCategory=ctgy)#柱状图
##其它可视化的图，cnetplot, heatplot, emapplot, goplot等，参考https://blog.csdn.net/weixin_43358851/article/details/83378100
cnetplot(ego_bp,showCategory = 2)
##自定义要展示的标签
cnetplot(ego_bp, node_label="category",cex_label_category = 1.2)
cnetplot(ego_bp, node_label="gene", cex_label_gene = 0.8)
cnetplot(ego_bp, node_label="all")
cnetplot(ego_bp, node_label="none",color_category='firebrick',color_item ='steelblue')
cnetplot(ego_bp, node_label="all",cex_label_category = 1.2)

heatplot(ego_bp, showCategory = 8, #显示前8
         symbol = "rect", # 图形，可选"dot"
         pvalue = NULL,
         label_format = 30)

heatplot(ego_bp, showCategory = 8, #显示前8
         symbol = "dot", #改为dot
         pvalue = NULL,
         label_format = 30)

##画通路网络图
go1<- pairwise_termsim(ego_bp)
dim(go1@result)
emapplot(go1)
upsetplot(go1)

#将BP、MF、CC途径的富集结果挑选前5条绘制在一张图上
dotplot(ego_all, split="ONTOLOGY",showCategory=5)+ facet_grid(ONTOLOGY~.,scale="free")
barplot(ego_all, split="ONTOLOGY",showCategory=5)+ facet_grid(ONTOLOGY~.,scale="free")
#将ont=ALL，换成CC、BP、MF分别进行富集
goCC <- enrichGO(diff_gene_entrez,OrgDb = org.Hs.eg.db, ont='CC',pAdjustMethod = 'BH',pvalueCutoff = 0.05, qvalueCutoff = 0.2,keyType = 'ENTREZID')
goBP <- enrichGO(diff_gene_entrez,OrgDb = org.Hs.eg.db, ont='BP',pAdjustMethod = 'BH',pvalueCutoff = 0.05, qvalueCutoff = 0.2,keyType = 'ENTREZID')
goplot(goBP, showCategory = 5)#注意需要在单个CC、BP、MF结果中绘图
goMF <- enrichGO(diff_gene_entrez,OrgDb = org.Hs.eg.db, ont='MF',pAdjustMethod = 'BH',pvalueCutoff = 0.05, qvalueCutoff = 0.2,keyType = 'ENTREZID')
goplot(goMF, showCategory = 5)



# 1. KEGG富集 ID转换
id_conversion <- bitr(diff_gene, 
                      fromType = "ENSEMBL", 
                      toType = c("ENTREZID", "SYMBOL"),
                      OrgDb = org.Hs.eg.db)

# 2. 提取唯一ENTREZID
diff_gene_entrez <- unique(na.omit(id_conversion$ENTREZID))

# 3. KEGG富集
kegg <- enrichKEGG(gene = diff_gene_entrez,
                   organism = 'hsa',
                   keyType = 'kegg',
                   pvalueCutoff = 0.05,
                   pAdjustMethod = 'BH',
                   minGSSize = 3,
                   maxGSSize = 500,
                   qvalueCutoff = 0.2,
                   use_internal_data = FALSE)

# =========================================================================
# 【关键步骤】把 geneID 转换成 基因名（SYMBOL）
# =========================================================================
kegg_df <- setReadable(kegg, OrgDb = org.Hs.eg.db, keyType = "ENTREZID")

# 4. 导出带基因名的结果表格（geneID列直接是基因名）
write.csv(kegg_df, file = "C:/Users/eeeqi/Desktop/博士毕业论文存档/03分析结果/SULT1C2敲减转录组数据分析/美吉SULT1C2-SKOV3敲减5V5数据分析/keggdown_with_gene_names.csv", row.names = F)

# 5. 查看（现在已经显示基因名）
head(kegg_df$geneID)

# 6. 画图（自动显示基因名）
dotplot(kegg_df, showCategory = 10, title = "KEGG Enrichment (Down-regulated genes)")
barplot(kegg_df, showCategory = 10, title = "KEGG Barplot")



##其它富集方法
ENid<-unique(id_conversion$ENTREZID)
DO <- enrichDO(gene          = ENid,
               ont           = "HDO",
               pvalueCutoff  = 0.05,
               pAdjustMethod = "BH",
               universe      = names(ENid),
               minGSSize     = 5,
               maxGSSize     = 500,
               qvalueCutoff  = 0.05,
               readable      = FALSE)
#使用 enrichDO进行 DO(疾病本体论)富集
ncg <- enrichNCG(ENid)#使用enrichNCG 进行癌基因网络富集
dgn<-enrichDGN(ENid)#使用 enrichDGN 进行疾病基因网络富集
write.csv(DO,file = "C:/Users/eeeqi/Desktop/博士毕业论文存档/03分析结果/SULT1C2敲减转录组数据分析/美吉SULT1C2-SKOV3敲减5V5数据分析/dodown.csv")
write.table(DO, "C:/Users/eeeqi/Desktop/博士毕业论文存档/03分析结果/SULT1C2敲减转录组数据分析/美吉SULT1C2-SKOV3敲减5V5数据分析/dodown.xls", col.names = NA, quote=F, sep = "\t")
write.csv(ncg,file = "C:/Users/eeeqi/Desktop/博士毕业论文存档/03分析结果/SULT1C2敲减转录组数据分析/美吉SULT1C2-SKOV3敲减5V5数据分析/ncgdown.csv")
write.table(ncg, "C:/Users/eeeqi/Desktop/博士毕业论文存档/03分析结果/SULT1C2敲减转录组数据分析/美吉SULT1C2-SKOV3敲减5V5数据分析/ncgdown.xls", col.names = NA, quote=F, sep = "\t")
write.csv(dgn,file = "C:/Users/eeeqi/Desktop/博士毕业论文存档/03分析结果/SULT1C2敲减转录组数据分析/美吉SULT1C2-SKOV3敲减5V5数据分析/dgndown.csv")
write.table(dgn, "C:/Users/eeeqi/Desktop/博士毕业论文存档/03分析结果/SULT1C2敲减转录组数据分析/美吉SULT1C2-SKOV3敲减5V5数据分析/dgndown.xls", col.names = NA, quote=F, sep = "\t")
dim(ncg@result)
#可视化，同上
dotplot(dgn, showCategory=10) #气泡图
dotplot(ncg, showCategory=10) #气泡图
barplot(dgn,showCategory=10,drop=T) #柱状图
dotplot(DO, showCategory=10) #气泡图
