
# 加载必要的库
library(ggplot2)
library(ggrepel)
library(AnnotationDbi)
library(org.Hs.eg.db)  # 用于基因ID转换
library(dplyr)
library(tidyverse)

# 读取原始差异表达数据
deg.data <- read.table(
  "C:/Users/eeeqi/Desktop/RDATA/outputfile-DESeq2.txt", 
  header = TRUE, 
  stringsAsFactors = FALSE
)

# 预处理：添加ENSEMBL ID列
deg.data$ENSEMBL <- rownames(deg.data)
rownames(deg.data) <- NULL

# 使用org.Hs.eg.db添加基因符号列
# 步骤1: 创建ID转换映射
id_map <- mapIds(
  org.Hs.eg.db,
  keys = deg.data$ENSEMBL,
  column = "SYMBOL",      # 获取基因符号
  keytype = "ENSEMBL",    # 原始ID类型为ENSEMBL
  multiVals = "first"     # 多个匹配时取第一个
)

# 步骤2: 添加基因符号列到数据框
deg.data$GeneSymbol <- id_map

# 检查映射结果
print(paste("成功映射比例:", 
            round(mean(!is.na(deg.data$GeneSymbol)) * 100, 1), "%"))

# 计算-log10(p值)
deg.data$log10P <- -log10(deg.data$pvalue)

# 设置差异表达分组（修复类型问题）
deg.data <- deg.data %>%
  mutate(
    # 确保Group列是字符向量类型
    Group = as.character({
      case_when(
        pvalue < 0.05 & log2FoldChange > 1 ~ "up-regulated",
        pvalue < 0.05 & log2FoldChange < -1 ~ "down-regulated",
        TRUE ~ "not-significant"
      )
    }),
    # 设置Significance为因子
    Significance = case_when(
      pvalue == 0 ~ "P≈0",
      pvalue < 0.001 ~ "*** P<0.001",
      pvalue < 0.05 ~ "** P<0.05",
      TRUE ~ "NS"
    ) %>% factor(levels = c("P≈0", "*** P<0.001", "** P<0.05", "NS")),
    
    # 设置标签
    Label = case_when(
      !is.na(GeneSymbol) & GeneSymbol == "SULT1C2" ~ "SULT1C2",
      pvalue < 0.05 & abs(log2FoldChange) > 4 ~ GeneSymbol,  # 显著变化大的基因
      log10P > 200 ~ GeneSymbol,  # 极其显著的基因
      TRUE ~ NA_character_  # 其他设为NA，避免空字符串问题
    )
  ) %>%
  # 显式转换Group列为因子（确保统计函数正常工作）
  mutate(Group = factor(
    Group,
    levels = c("not-significant", "up-regulated", "down-regulated")
  ))
# 修正后的分组统计（不会出错）
group_stats <- deg.data %>% 
  group_by(Group) %>% 
  summarise(Count = n()) %>% 
  ungroup() %>%
  mutate(Percentage = round(Count / sum(Count) * 100, 1))
print(group_stats)

# 计算上下调基因数量（用于图上的标注）
up_count <- sum(deg.data$Group == "up-regulated", na.rm = TRUE)
down_count <- sum(deg.data$Group == "down-regulated", na.rm = TRUE)

# 获取有效的坐标轴范围 (修复无限值问题)
max_log10P <- max(deg.data$log10P[is.finite(deg.data$log10P)], na.rm = TRUE)
min_log2FC <- min(deg.data$log2FoldChange, na.rm = TRUE)
max_log2FC <- max(deg.data$log2FoldChange, na.rm = TRUE)

# 创建火山图
volcano_plot <- ggplot(deg.data, aes(x = log2FoldChange, y = log10P)) +
  # 创建散点映射 - 显著增大点的大小
  geom_point(aes(color = Group, shape = Significance), 
             size = 3.5,  # 显著增大点大小
             alpha = 0.8) +
  
  # 标注SULT1C2 - 修复条件判断问题
  {
    sult_row <- deg.data[!is.na(deg.data$GeneSymbol) & deg.data$GeneSymbol == "SULT1C2", ]
    if (nrow(sult_row) > 0) {
      list(
        geom_point(data = sult_row, 
                   color = "red", 
                   size = 6,  # 增大的点大小
                   shape = 18),
        geom_label_repel(
          data = sult_row,
          aes(label = "SULT1C2"),
          fill = "red",
          color = "white",
          fontface = "bold",
          box.padding = 0.8,
          segment.color = "red"
        )
      )
    } else {
      NULL  # 如果没有SULT1C2，不添加任何标注
    }
  } +
  
  # 添加上调基因数量标注 (确保位置合理)
  annotate("text", 
           x = max_log2FC * 0.55,  
           y = max_log10P*1.2 ,  # 顶部但留出空间
           label = paste0(" (n = ", up_count, ")"),
           hjust = 0, 
           vjust = 1,  # 顶部对齐
           color = "#e41a1c", 
           size = 4.5,  # 增大文本大小
           fontface = "bold") +
  
  # 添加下调基因数量标注 (确保位置合理)
  annotate("text", 
           x = min_log2FC* 0.85, 
           y = max_log10P*1.2,  # 顶部但留出空间
           label = paste0(" (n = ", down_count, ")"),
           hjust = 1,  # 右对齐
           vjust = 1,  # 顶部对齐
           color = "#377eb8", 
           size = 4.5,  # 增大文本大小
           fontface = "bold") +
  
  # 添加参考线
  geom_vline(xintercept = c(-1, 1), 
             linetype = "dashed", 
             color = "grey30", 
             alpha = 0.7) +
  
  geom_hline(yintercept = -log10(0.05), 
             linetype = "dashed", 
             color = "grey30", 
             alpha = 0.7) +
  
  # 添加参考线说明 - 简化版
  annotate("text", 
           x = mean(c(min_log2FC, max_log2FC)),  # 中间位置
           y = -log10(0.05) + 0.5, 
           label = "FDR = 0.05", 
           size = 3.5, 
           color = "grey30") +
  
  # 自定义颜色方案
  scale_color_manual(
    name = "表达分组",
    values = c(
      "up-regulated" = "#e41a1c",
      "down-regulated" = "#377eb8",
      "not-significant" = "grey80"
    )
  ) +
  
  # 自定义点形状
  scale_shape_manual(
    name = "显著性水平",
    values = c("P≈0" = 17, "*** P<0.001" = 16, 
               "** P<0.05" = 15, "NS" = 1)
  ) +
  
  # 坐标轴标签
  labs(
    title = "差异表达基因火山图",
    x = expression(log[2]("FoldChange")),
    y = expression(-Log[10]("P value"))
  ) +
  
  # 主题设置
  theme_bw(base_size = 14) +
  theme(
    plot.title = element_text(face = "bold", size = 18, hjust = 0.5),
    axis.title = element_text(face = "bold"),
    axis.title.x = element_text(margin = margin(t = 10)),
    axis.title.y = element_text(margin = margin(r = 10)),
    axis.text = element_text(size = 12),
    legend.position = "right",
    panel.grid.major = element_line(color = "grey90", size = 0.2),
    panel.grid.minor = element_blank()
  ) +
  
  # 扩展坐标轴
  expand_limits(
    y = max_log10P * 1.15,  # 扩展更多Y轴空间
    x = c(min_log2FC * 0.5, max_log2FC * 1.1)  # 扩展X轴空间
  )

# 绘制图形
print(volcano_plot)
