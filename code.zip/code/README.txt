SKOV3_SULT1C2_knockdown_5v5/
  Five si-352 libraries versus five negative-control (NC) libraries.
  01_DESeq2_GO_KEGG.R
    Reads gene_counts.xls. DESeq2 compares TEST (gbd) versus CONTROL (ctrl), with five libraries in each group.
    Up-regulated: pvalue < 0.05 and log2FoldChange > 1.
    Down-regulated: pvalue < 0.05 and log2FoldChange < -0.5.
    clusterProfiler GO is then run on the up-regulated genes, and KEGG on the down-regulated genes.

  02_volcano.R
    Reads outputfile-DESeq2.txt and draws the volcano plot. Threshold: pvalue < 0.05 and |log2FoldChange| > 1.

  03_GSEA_KEGG.R
    Runs gseKEGG on the log2FoldChange of all genes.


OVCAR3_SULT1C2_overexpression_2v2/
  Two SULT1C2-overexpression libraries versus two empty-vector (EV) libraries. The original filenames still say knockdown; the analysis is overexpression.
  01_DESeq2_GO_KEGG.R
    Reads gene.count.matrix.xls. Columns are renamed, in order, to control1, control2, TEST1, and TEST2.
    DESeq2 compares gbd versus ctrl. Both directions use pvalue < 0.05 and |log2FoldChange| > 1.
    GO and KEGG are run on the down-regulated genes.

  02_volcano.R
    Reads outputfile-DESeq2.txt and draws the volcano plot.

  03_GSEA_KEGG.R
    Runs gseKEGG on the log2FoldChange of all genes.

