# ------------ 第一步：ID转换 ------------
library(clusterProfiler)
library(org.Hs.eg.db)
library(tidyverse)

allgene <- read.table("C:/Users/eeeqi/Desktop/美吉数据下载/outputfile-DESeq2.txt", header=T, sep="\t")

# 获取Ensemble ID（不含版本号）
ensembl_ids <- sub("\\..*$", "", rownames(allgene))

# ID转换映射（注意：可能有1对多映射）
id_map <- bitr(
  ensembl_ids,
  fromType = "ENSEMBL",
  toType = c("SYMBOL", "ENTREZID"),
  OrgDb = org.Hs.eg.db
)

# 合并到结果数据框，并去除重复（每个带版本的Ensembl ID保留一行）
allgene_annotated <- allgene %>%
  rownames_to_column("ENSEMBL_VERSIONED") %>%
  mutate(ENSEMBL = sub("\\..*$", "", ENSEMBL_VERSIONED)) %>%
  left_join(id_map, by = "ENSEMBL") %>%
  distinct(ENSEMBL_VERSIONED, .keep_all = TRUE)  # 确保唯一Ensembl ID

#write.table(allgene_annotated, "C:/Users/eeeqi/Desktop/SULT1C2敲减和过表达转录组数据分析/allgene_annotated.xls", col.names = NA, quote=F, sep = "\t")
# ------------ 第二步：准备基因列表 ------------

# 创建ENTREZID版本的基因列表（去除重复ENTREZID：取平均log2FoldChange）
gene_list_ENTREZID <- allgene_annotated %>%
  filter(!is.na(ENTREZID) & !is.na(log2FoldChange)) %>%
  group_by(ENTREZID) %>%
  summarise(log2FoldChange = mean(log2FoldChange)) %>%
  arrange(desc(log2FoldChange)) %>%
  pull(log2FoldChange, name = "ENTREZID")
message(paste("ENTREZID基因列表长度:", length(gene_list_ENTREZID)))


# 执行GSEA分析（KEGG），最新基因但需要网络支持
options(timeout=300)
set.seed(123)
gsea_results <- gseKEGG(
  geneList    = gene_list_ENTREZID,
  organism    = "hsa",      # 人类
  keyType     = "ncbi-geneid",  # 使用entrez ID
  nPerm       = 10000,      # 置换次数
  minGSSize   = 15,         # 最小基因集大小
  maxGSSize   = 500,        # 最大基因集大小
  pvalueCutoff = 0.05,
  pAdjustMethod = "BH",     # 多重检验校正方法
  verbose     = FALSE
)

# 步骤4：结果处理 - 将核心富集基因Entrez ID转换为Symbol
library(dplyr)
library(purrr)

# 创建EntrezID到Symbol的唯一映射字典（基于注释后数据）
entrez_symbol_map <- allgene_annotated %>%
  select(ENTREZID, SYMBOL) %>%
  distinct(ENTREZID, .keep_all = TRUE) %>%
  filter(!is.na(ENTREZID) & !is.na(SYMBOL)) %>%
  {setNames(as.character(.$SYMBOL), .$ENTREZID)}

# 定义转换函数（安全处理缺失映射）
convert_core_enrichment <- function(entrez_string) {
  entrez_vec <- str_split(entrez_string, "/")[[1]]
  symbol_vec <- map_chr(entrez_vec, function(id) {
    ifelse(id %in% names(entrez_symbol_map),
           entrez_symbol_map[[id]],
           paste0("UNK_", id))  # 未映射的ID添加UNK_前缀
  })
  paste(symbol_vec, collapse = "/")
}

# 提取结果并转换core_enrichment列
results_df <- as.data.frame(gsea_results) %>%
  mutate(core_enrichment = map_chr(core_enrichment, convert_core_enrichment))

# 保存结果（全小写文件名）
write.csv(results_df, file = "c:/users/eeeqi/desktop/gsea_results_symbol.csv", 
          row.names = FALSE, quote = TRUE)
#读取存储的结果
data<- read.csv(
  file = "c:/users/eeeqi/desktop/gsea_results_symbol.csv",
  header = TRUE,      # 第一行为列名
  sep = ",",          # CSV文件分隔符
  stringsAsFactors = FALSE # 避免自动转为因子
)


# ------------ 第四步：可视化 ------------
# 绘制Top 5路径
top_pathways <- gsea_results@result %>%arrange(p.adjust) %>%head(5) %>%pull(ID)
gseaplot2(gsea_results,geneSetID = top_pathways, pvalue_table = TRUE, title = "Top Enriched Hallmark Pathways")
gseaplot2(gsea_results,geneSetID =c(1,2),pvalue_table = T)
gseaplot2(gsea_results,geneSetID =c(1),pvalue_table = F)
gseaplot(gsea_results,geneSetID = 1)
ridgeplot(gsea_results)#脊线图将可视化 GSEA 富集类别的核心富集基因的表达分布,可以帮助解释上调/下调通路  

#过滤需要画图的通路，本次画全部p.adjust < 0.05的通路
all_pathways <- as.data.frame(gsea_results) %>%
  filter(p.adjust< 0.05) %>%  # 添加显著性过滤
  arrange(NES) %>%  # 按NES升序（最负的排前面）
  mutate(Log10FDR = -log10(p.adjust))  # 创建对数转换列

# 检查数据集
if(nrow(all_pathways) > 0) {
  # 限制最多显示20个通路（按NES排序）
  show_n <- min(20, nrow(all_pathways))
  plot_data<- all_pathways[1:show_n, ]

# 创建气泡图
ggplot(plot_data, 
       aes(x = NES, 
           y = reorder(Description, -NES),
           size = setSize,
           color = Log10FDR)) +
  geom_point(alpha = 0.85, shape = 19) +
  geom_vline(xintercept = -3, linetype = "dashed", 
             color = "darkblue", linewidth = 0.7) +
  
  # 尺寸和颜色标尺
  scale_size_continuous(
    range = c(4, 10),
    name = "基因数量",
    breaks = c(20, 50, 100),
    labels = scales::comma_format()
  ) +
  scale_color_gradientn(
    colors = c("#0571b0", "#ca0020"),
    name = "Log10FDR",
    limits = c(1,3)
  ) +
  
  # 标签和主题
  labs(
    title = "显著下调的KEGG通路 (NES < -1)",
    subtitle = "筛选条件: FDR < 0.05 & NES <-1",
    x = "标准化富集分数 (NES)",
    y = NULL,
  ) +
  
  # 坐标轴范围控制 (核心调整!)
  coord_cartesian(xlim = c(-3,-1)) +
  
  # 主题定制
  theme_classic(base_size = 14) +
  theme(
    axis.title.x = element_text(size = 14, face = "bold"),
    axis.text.y = element_text(size = 12, face = "bold", color = "black"),
    plot.title = element_text(face = "bold", hjust = 0.5, size = 16),
    plot.subtitle = element_text(hjust = 0.5, color = "gray30"),
    legend.title = element_text(face = "bold"),
    panel.grid.major.y = element_line(color = "grey90", linetype = "dotted"),
    plot.caption = element_text(color = "gray40", size = 10)
  )

} else {
  message("未发现NES≥1的显著通路")
}


# 保存结果
write.csv(all_pathways, file = "C:/Users/eeeqi/Desktop/all_pathways.csv", row.names = FALSE)



##其它富集方法（GSEA富集和enrich最大区别在于需要log2fc值。类似于GSEA的疾病基因集富集分析有以下3个函数(都以 gse 开头，gseDO，gseNCG，gseDGN)，分别进行疾病本体 DO、癌基因网络、疾病基因网络的基因集富集分析）
library(DOSE)
# 使用dplyr处理
gsea_data <- allgene_annotated %>%
  # 先选择需要的列并过滤NA
  dplyr::select(ENTREZID, log2FoldChange) %>%
  dplyr::filter(!is.na(ENTREZID) & !is.na(log2FoldChange)) %>%
  # 按ENTREZID分组，计算每个基因的平均log2FoldChange
  dplyr::group_by(ENTREZID) %>%
  dplyr::summarise(log2FoldChange = mean(log2FoldChange, na.rm = TRUE)) %>%
  # 按log2FoldChange降序排列
  dplyr::arrange(desc(log2FoldChange)) %>%
  # 创建命名向量（名称是ENTREZID，值是log2FoldChange）
  tibble::deframe()

y<-gseDO(gsea_data, minGSSize= 120, pvalueCutoff= 0.2, pAdjustMethod = "BH", verbose= FALSE)#DO基因集富集
ridgeplot(y)

ncg<- gseNCG(gsea_data, pvalueCutoff = 0.5, pAdjustMethod = "BH", verbose= FALSE)#癌基因网络基因集富集
ncg<-setReadable(ncg,'org.Hs.eg.db')
ridgeplot(ncg)

dgn<- gseDGN(gsea_data, pvalueCutoff = 0.2, pAdjustMethod = "BH", verbose= FALSE)#疾病基因网络基因集富集
dgn<-setReadable(dgn,'org.Hs.eg.db')
ridgeplot(dgn)

# 提取结果并转换core_enrichment列
results_df <- as.data.frame(y) %>%
  mutate(core_enrichment = map_chr(core_enrichment, convert_core_enrichment))

# 保存结果（全小写文件名）
write.csv(results_df, file = "c:/users/eeeqi/desktop/DO.csv", 
          row.names = FALSE, quote = TRUE)

